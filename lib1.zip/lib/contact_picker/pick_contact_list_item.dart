import 'package:flutter/material.dart';

class ContactPickerListItem extends StatefulWidget {
  const ContactPickerListItem({Key? key, required this.thumbnail, required this.name, required this.number}) : super(key: key);

  final Container thumbnail;
  final String name;
  final String number;

  @override
  _ContactPickerListItemState createState() => _ContactPickerListItemState();
}

class _ContactPickerListItemState extends State<ContactPickerListItem> {
  bool isTicked = false;

  @override
  Widget build(BuildContext context) {
    return _buildListItem();
  }

  Container _buildListItem() {
    return Container(
      child: isTicked ? _buildTickedListTile() : _buildUntickedListTile(),
      decoration: BoxDecoration(
        color: isTicked ? const Color(0x461565C0) : Colors.transparent,
        borderRadius: BorderRadius.circular(10.0),
      ),
      margin: const EdgeInsets.fromLTRB(10.0, 5.0, 10.0, 0.0),
    );
  }

  ListTile _buildTickedListTile() {
    Container buildLeading() {
      return Container(
        child: const Icon(Icons.done, color: Colors.white,),
        decoration: const BoxDecoration(
          color: Color(0xFF1565C0),
          shape: BoxShape.circle,
        ),
        width: 50.0,
        height: 50.0,
        padding: const EdgeInsets.all(5.0),
      );
    }

    return ListTile(
      leading: buildLeading(),
      title: Text(widget.name),
      subtitle: Text(widget.number),
      onTap: _toggle,
    );
  }

  ListTile _buildUntickedListTile() {
    return ListTile(
      leading: widget.thumbnail,
      title: Text(widget.name),
      subtitle: Text(widget.number),
      onTap: _toggle,
    );
  }

  void _toggle() {
    setState(() => isTicked = !isTicked);
  }
}
