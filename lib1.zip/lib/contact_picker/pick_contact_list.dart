import 'package:flutter/material.dart';

//import 'package:permission_handler/permission_handler.dart';
import 'package:contacts_service/contacts_service.dart';

import 'pick_contact_list_item.dart';

class ContactPickerList extends StatefulWidget {
  const ContactPickerList({Key? key}) : super(key: key);

  @override
  _ContactPickerListState createState() => _ContactPickerListState();
}

class _ContactPickerListState extends State<ContactPickerList> {
  late List<Contact> _contacts;

  // @override
  // void initState() {
  //   super.initState();
  //   _contacts = _loadContacts();
  // }

  @override
  Widget build(BuildContext context) {
    //return _contactsLoaded ? _buildContactsList() : _buildProgressIndicator();
    return FutureBuilder<List<Contact>>(
        future: _loadContacts(),
        builder: (context, snapshot) {
          if (snapshot.hasData) {
            _contacts = snapshot.data!;
            return _buildContactsList();
          }
          return _buildProgressIndicator();
        },
    );
  }

  Future<List<Contact>> _loadContacts() async {
    return await ContactsService.getContacts(withThumbnails: false);
  }

  ListView _buildContactsList() {
    ContactPickerListItem buildItem(BuildContext context, int index) {
      Contact contact = _contacts[index];
      String name = contact.displayName!;
      List<String> names = name.split(' ');
      String? lastName = names.length > 1 ? names[names.length - 1] : null;

      Container buildInitialsThumbnail() {
        return Container(
          child: Center(
            child: Text(
              '${name[0]}${lastName != null ? lastName[0] : ''}',
              style: const TextStyle(
                color: Colors.white,
                fontSize: 24,
              ),
            ),
          ),
          decoration: const BoxDecoration(
            color: Color(0x461565C0),
            shape: BoxShape.circle,
          ),
          width: 50.0,
          height: 50.0,
          padding: const EdgeInsets.all(5.0),
        );
      }

      return ContactPickerListItem(
          thumbnail: buildInitialsThumbnail(),
          name: name,
          number: '+48 123 456 789'//contact.phones![0].toString(), // fix null
      );
    }

    return ListView.builder(
        itemBuilder: buildItem,
        addAutomaticKeepAlives: true,
    );
  }

  Center _buildProgressIndicator() {
    return const Center(
      child: CircularProgressIndicator(
        color: Color(0xFF1565C0),
      ),
    );
  }
}


/*
class PickContactsList extends StatefulWidget {
  const PickContactsList({Key? key}) : super(key: key);

  @override
  _PickContactsListState createState() => _PickContactsListState();
}

class _PickContactsListState extends State<PickContactsList> {
  late List<Contact> _contacts;

  _PickContactsListState() {
    getContacts();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'cliary',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: _buildApp(),
    );
  }

  Widget _buildApp() {
    // checkForPermissions();

    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: _doNothing,
        ),
        title: const Text('Wybierz klientów'),
      ),
      body: ListView.builder(itemBuilder: _buildListItem),
    );
  }

  Widget _buildListItem(BuildContext context, int index) {
    return const PickContactLI(
      thumbnail: Icon(
        Icons.account_circle,
        color: Color(0xFF1565C0),
        size: 40,
      ),
      name: _contacts[index].displayName,
      number: '+48 123 456 789',
    );
  }

  void getContacts() async {
    _contacts = await ContactsService.getContacts(withThumbnails: false);
  }

  void _doNothing() {}
}


class PickContactList extends StatelessWidget {

late List<Contact> _contacts;

@override
Widget build(BuildContext context) {
  return MaterialApp(
    title: 'cliary',
    theme: ThemeData(
      primarySwatch: Colors.blue,
    ),
    home: _buildApp(),
  );
}

Widget _buildApp() {
  // checkForPermissions();

  return Scaffold(
    appBar: AppBar(
      leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: _doNothing,
      ),
      title: const Text('Wybierz klientów'),
    ),
    body: ListView.builder(itemBuilder: (_, index) => const PickContactLI(
      thumbnail: Icon(
        Icons.account_circle,
        color: Color(0xFF1565C0),
        size: 40,
      ),
      name: 'Dummy Contact',
      number: '+48 123 456 789',
    )),// This trailing comma makes auto-formatting nicer for build methods.
  );
}
}*/
