import 'package:flutter/material.dart';

class AddServiceListItem extends StatelessWidget {
  const AddServiceListItem({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(5),
      child: Row(
        children: [
          const Icon(
            Icons.add,
            color: Color(0x99000000),
            size: 20,
          ),
          Expanded(
            child: TextFormField(
              cursorColor: const Color(0xFF777777),
              keyboardType: TextInputType.text,
              textCapitalization: TextCapitalization.sentences,
              style: const TextStyle(
                fontFamily: 'Varela',
                fontSize: 16,
              ),
              decoration: const InputDecoration(
                isDense: true,
                border: InputBorder.none,
                focusedBorder: InputBorder.none,
                enabledBorder: InputBorder.none,
                errorBorder: InputBorder.none,
                disabledBorder: InputBorder.none,
                contentPadding: EdgeInsets.all(0),
                hintText: "Dodaj usługę",
              ),
            ),
          ),
        ],
      ),
    );
  }
}
