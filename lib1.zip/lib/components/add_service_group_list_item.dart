import 'package:flutter/material.dart';

class AddServiceGroupListItem extends StatelessWidget {
  const AddServiceGroupListItem({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        const Divider(
          color: Color(0xFF555555),
          thickness: 1,
          height: 1,
        ),
        TextButton(
          onPressed: () {},
          style: TextButton.styleFrom(
              primary: const Color(0xFF1565C0),
              padding: const EdgeInsets.all(0),
              tapTargetSize: MaterialTapTargetSize.shrinkWrap,
              shape: const RoundedRectangleBorder(
                borderRadius: BorderRadius.vertical(
                  bottom: Radius.circular(15),
                ),
              )
          ),
          child: const Text(
            'Dodaj grupę',
            style: TextStyle(
              fontFamily: 'Varela',
              fontSize: 18,
            ),
          ),
        ),
        /*Container(
          decoration: const BoxDecoration(
            borderRadius: BorderRadius.vertical(
              bottom: Radius.circular(15),
            ),
          ),
          padding: const EdgeInsets.fromLTRB(5, 5, 10, 5),
          child: Expanded(
            child: TextFormField(
              cursorColor: const Color(0xFF1565C0),
              keyboardType: TextInputType.text,
              textCapitalization: TextCapitalization.sentences,
              textAlign: TextAlign.center,
              style: const TextStyle(
                fontFamily: 'Varela',
                fontSize: 18,
              ),
              decoration: const InputDecoration(
                isDense: true,
                border: InputBorder.none,
                focusedBorder: InputBorder.none,
                enabledBorder: InputBorder.none,
                errorBorder: InputBorder.none,
                disabledBorder: InputBorder.none,
                contentPadding: EdgeInsets.all(0),
                hintText: "Dodaj grupę",
                hintStyle: TextStyle(
                  color: Color(0xFF1565C0),
                ),
              ),
            ),
          ),
        ),*/
        /*Container(
          padding: const EdgeInsets.fromLTRB(5, 5, 10, 5),
          child: Row(
            children: [
              const Icon(
                Icons.add,
                color: Color(0xFF1565C0),
                size: 25,
              ),
              Expanded(
                child: TextFormField(
                  cursorColor: const Color(0xFF1565C0),
                  keyboardType: TextInputType.text,
                  textCapitalization: TextCapitalization.sentences,
                  style: const TextStyle(
                    fontFamily: 'Varela',
                    fontSize: 18,
                  ),
                  decoration: const InputDecoration(
                    isDense: true,
                    border: InputBorder.none,
                    focusedBorder: InputBorder.none,
                    enabledBorder: InputBorder.none,
                    errorBorder: InputBorder.none,
                    disabledBorder: InputBorder.none,
                    contentPadding: EdgeInsets.all(0),
                    hintText: "Dodaj grupę",
                    hintStyle: TextStyle(
                      color: Color(0xFF1565C0),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),*/
      ],
    );
  }
}
