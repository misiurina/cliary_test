import 'package:cliary_test/components/add_service_list_item.dart';
import 'package:cliary_test/components/service_group_list_item.dart';
import 'package:cliary_test/components/service_list_item.dart';
import 'package:flutter/material.dart';

class ServiceGroupList extends StatelessWidget {
  const ServiceGroupList({
    Key? key,
    required this.group,
    required this.services,
  }) : super(key: key);

  // final ServiceGroupListItem group;
  final Widget group;
  final List<ServiceListItem> services;

  @override
  Widget build(BuildContext context) {
    return IntrinsicHeight(
      child: Column(
        children: [
          group,
          for (var service in services) ...[
            service,
            // if (service != services.last)
            const Divider(
              color: Color(0xFF333333),
              thickness: 1,
              height: 1,
              indent: 5,
              endIndent: 5,
            ),
          ],
          const AddServiceListItem(),
        ],
      ),
    );
  }
}
