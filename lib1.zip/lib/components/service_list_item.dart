import 'package:flutter/material.dart';

class ServiceListItem extends StatelessWidget {
  const ServiceListItem({
    Key? key,
    required this.displayName,
    this.description,
    this.time,
    this.price,
  }) : super(key: key);

  final String displayName;
  final String? description, time, price;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: () {},
        // highlightColor: Color(0xFFB5EAD6 - 0x88000000),
        // splashColor: Color(0xFFB5EAD6),
        highlightColor: Colors.transparent,
        child: IntrinsicHeight(
          child: Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(5),
                      child: Text(
                        displayName,
                        style: const TextStyle(
                          fontFamily: 'Varela',
                          fontSize: 16,
                          color: Color(0xFF333333),
                        ),
                      ),
                    ),
                    if (description != null) Padding(
                      padding: const EdgeInsets.fromLTRB(5, 0, 5, 5),
                      child: Text(
                        description!,
                        style: const TextStyle(
                          fontFamily: 'Varela',
                          fontSize: 12,
                          color: Color(0x99000000),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Column(
                mainAxisAlignment: (time != null && price != null)
                    ? MainAxisAlignment.spaceBetween : MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  if (time != null) Padding(
                    padding: const EdgeInsets.fromLTRB(0, 5, 5, 5),
                    child: Text(
                      time!,
                      style: const TextStyle(
                        fontFamily: 'Varela',
                        fontSize: 12,
                        color: Color(0x99000000),
                      ),
                    ),
                  ),
                  if (price != null) Padding(
                    padding: const EdgeInsets.fromLTRB(0, 5, 5, 5),
                    child: Text(
                      price!,
                      style: const TextStyle(
                        fontFamily: 'Varela',
                        fontSize: 12,
                        color: Color(0x99000000),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
