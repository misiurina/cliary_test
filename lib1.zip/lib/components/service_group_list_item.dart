import 'package:flutter/material.dart';

class ServiceGroupListItem extends StatelessWidget {
  const ServiceGroupListItem({
    Key? key,
    required this.groupName,
    required this.color,
    this.isFirst = false,
  }) : super(key: key);

  final String groupName;
  final int color;
  final bool isFirst;

  @override //0xFFB5EAD6
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Color(color - 0x88000000),
        borderRadius: BorderRadius.vertical(
          top: isFirst ? const Radius.circular(15) : Radius.zero,
        ),
      ),
      child: IntrinsicHeight(
        child: Column(
          children: [
            Row(
              children: [
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(10, 5, 10, 5),
                    child: Text(
                      groupName,
                      style: const TextStyle(
                        fontFamily: 'Varela',
                        fontSize: 18,
                        color: Color(0xFF333333),
                      ),
                    ),
                  ),
                ),
                Container(
                  margin: const EdgeInsets.fromLTRB(0, 5, 10, 5),
                  width: 20,
                  height: 20,
                  decoration: BoxDecoration(
                    border: Border.all(
                      color: const Color(0xFF333333),
                      width: 0.5,
                    ),
                    borderRadius: const BorderRadius.all(Radius.circular(15)),
                    color: Color(color),
                  ),
                  child: Material(
                    color: Colors.transparent,
                    child: InkWell(
                      onTap: () {},
                      highlightColor: Colors.transparent,
                      borderRadius: const BorderRadius.all(Radius.circular(15)),
                    ),
                  ),
                ),
              ],
            ),
            const Divider(
              color: Color(0xFF333333),
              thickness: 1,
              height: 1,
            ),
          ],
        ),
      ),
    );
  }
}
