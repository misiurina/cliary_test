import 'package:cliary_test/components/add_service_group_list_item.dart';
import 'package:cliary_test/components/service_group_list.dart';
import 'package:flutter/material.dart';

class ServicesList extends StatelessWidget {
  const ServicesList({
    Key? key,
    required this.groups,
  }) : super(key: key);

  final List<ServiceGroupList> groups;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(
          width: 1,
          color: const Color(0xFF333333),
        ),
        borderRadius: const BorderRadius.all(Radius.circular(15)),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.5),
            spreadRadius: 1,
            blurRadius: 3,
            offset: const Offset(0, 1), // changes position of shadow
          ),
        ],
      ),
      child: IntrinsicHeight(
        child: Column(
          children: [
            for (var group in groups) ...[
              group,
              if (group != groups.last) const Divider(
                color: Color(0xFF333333),
                thickness: 1,
                height: 1,
                endIndent: 0,
              ),
            ],
            const AddServiceGroupListItem(),
          ],
        ),
      ),
    );
  }
}
