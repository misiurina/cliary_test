import 'package:flutter/material.dart';

class BottomActionButton extends StatelessWidget {
  const BottomActionButton({
    Key? key,
    this.callback,
    this.icon,
    required this.label,
    this.primaryColor,
    this.onPrimaryColor
  }) : super(key: key);

  final void Function()? callback;
  final Icon? icon;
  final Text label;

  final Color? primaryColor, onPrimaryColor;

  @override
  Widget build(BuildContext context) {
    return (icon != null)
    ? ElevatedButton.icon(
      onPressed: callback ?? () {},
      style: ElevatedButton.styleFrom(
          primary: primaryColor ?? const Color(0xFF1565C0),
          onPrimary: onPrimaryColor ?? Colors.white,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(8),
          )
      ),
      icon: icon!,
      label: label,
    )
    : ElevatedButton(
      onPressed: callback ?? () {},
      style: ElevatedButton.styleFrom(
          primary: primaryColor ?? const Color(0xFF1565C0),
          onPrimary: onPrimaryColor ?? Colors.white,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(8),
          )
      ),
      child: label,
    );
  }
}