import 'package:flutter/material.dart';

class EditServiceGroupListItem extends StatelessWidget {
  const EditServiceGroupListItem({
    Key? key,
    required this.color,
    this.hint,
    this.isFirst = false,
  }) : super(key: key);

  final int color;
  final String? hint;
  final bool isFirst;

  @override //0xFFB5EAD6
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Color(color - 0x88000000),
        borderRadius: BorderRadius.vertical(
          top: isFirst ? const Radius.circular(15) : Radius.zero,
        ),
      ),
      child: IntrinsicHeight(
        child: Column(
          children: [
            Row(
              children: [
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(10, 5, 10, 5),
                    child: TextFormField(
                      cursorColor: const Color(0xFF1565C0),
                      keyboardType: TextInputType.text,
                      textCapitalization: TextCapitalization.sentences,
                      style: const TextStyle(
                        fontFamily: 'Varela',
                        fontSize: 18,
                        color: Color(0xFF333333),
                      ),
                      decoration: InputDecoration(
                        isDense: true,
                        border: InputBorder.none,
                        focusedBorder: InputBorder.none,
                        enabledBorder: InputBorder.none,
                        errorBorder: InputBorder.none,
                        disabledBorder: InputBorder.none,
                        contentPadding: const EdgeInsets.all(0),
                        hintText: hint ?? "",
                      ),
                    ),
                  ),
                ),
                Container(
                  margin: const EdgeInsets.fromLTRB(0, 5, 10, 5),
                  width: 20,
                  height: 20,
                  child: Material(
                    color: Colors.transparent,
                    child: InkWell(
                      borderRadius: const BorderRadius.all(Radius.circular(15)),
                      onTap: () {},
                      highlightColor: Colors.transparent,
                      child: const Icon(
                        Icons.delete,
                        size: 20,
                        color: Color(0xFF333333),
                      ),
                    ),
                  ),
                ),
              ],
            ),
            const Divider(
              color: Color(0xFF555555),
              thickness: 1,
              height: 1,
            ),
          ],
        ),
      ),
    );
  }
}
