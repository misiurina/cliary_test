import 'package:cliary_test/components/bottom_action_button.dart';
import 'package:cliary_test/components/bottom_action_buttons.dart';
import 'package:cliary_test/components/edit_service_group_list_item.dart';
import 'package:cliary_test/components/service_group_list.dart';
import 'package:cliary_test/components/service_group_list_item.dart';
import 'package:cliary_test/components/service_list_item.dart';
import 'package:cliary_test/components/services_list.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class SetUpServicesScreen extends StatelessWidget {
  const SetUpServicesScreen({Key? key}) : super(key: key);

  final ServicesList servicesList = const ServicesList(
    groups: [
      ServiceGroupList(
        group: EditServiceGroupListItem(
          hint: 'Depilacje',
          color: 0xFFB5EAD6,
          isFirst: true,
        ),
        services: [
          ServiceListItem(
            displayName: 'Depilacja woskiem',
            time: '~25 min',
            price: '80 zł',
          ),
          ServiceListItem(
            displayName: 'Depilacja pastą cukrową',
            description: 'Jak zwykła, tylko pastą cukrową.',
            time: '~30 min',
            price: '100 zł',
          ),
          ServiceListItem(
            displayName: 'Depilacja laserowa',
            price: '180 zł',
          ),
        ],
      ),
      ServiceGroupList(
        group: ServiceGroupListItem(
          groupName: 'Masaże',
          color: 0xFFF5D2D3,
        ),
        services: [
          ServiceListItem(
            displayName: 'Masaż ciała',
            description: 'Dekolt, ręce, plecy, nogi.',
            time: '~45 min',
          ),
          ServiceListItem(
            displayName: 'Masaż stóp',
          ),
        ],
      ),
    ],
  );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      //resizeToAvoidBottomInset: false,
      appBar: AppBar(
        backgroundColor: Colors.white,
        title: Text(
          'cliary',
          style: TextStyle(
            fontFamily: 'Varela',
            color: Colors.black,
            fontSize: 30,
            /*shadows: [
              Shadow(
                color: Colors.grey.withOpacity(0.5),
                blurRadius: 5,
                offset: const Offset(0, 0), // changes position of shadow
              ),
            ],*/
          ),
        ),
      ),
      body: Container(
        color: Colors.white,
        child: SingleChildScrollView(
          child: SizedBox(
            height: MediaQuery.of(context).size.height - (AppBar().preferredSize.height + MediaQuery.of(context).padding.top),
            child: Column(
              children: [
                Container(
                  // color: Colors.white,
                  padding: const EdgeInsets.all(10),
                  margin: const EdgeInsets.only(bottom: 10),
                  child: const Text(
                    'Wprowadź tu usługi, które wykonujesz. Nacisnij na usługę aby dodać dodatkowe informację lub nią usunąć. Nacisnij na kółko, aby zmienić kolor grupy. Wybrany kolor grupy zadecyduje o kolorze wpisu na linii czasu.',
                    style: TextStyle(
                      fontFamily: 'Varela',
                      color: Color(0x99000000),
                      fontSize: 15,
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(10, 0, 10, 10),
                  child: servicesList,
                ),
                const Spacer(),
                const BottomActionButtons(
                  leftButton: BottomActionButton(
                    label: Text(
                      'Wróć',
                      style: TextStyle(
                        fontFamily: 'Varela',
                      ),
                    ),
                    primaryColor: Colors.white,
                    onPrimaryColor: Color(0xFF1565C0),
                  ),
                  rightButton: BottomActionButton(
                    label: Text(
                      'Dalej',
                      style: TextStyle(
                        fontFamily: 'Varela',
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
