import 'package:cliary_test/components/bottom_action_button.dart';
import 'package:cliary_test/components/bottom_action_buttons.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class WelcomeScreen extends StatelessWidget {
  const WelcomeScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        color: const Color(0xFF1565C0),
        child: Column(
          children: [
            Expanded(
              child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      'Witaj w cliary!',
                      style: GoogleFonts.varelaRound(
                        fontSize: 34,
                        color: Colors.white,
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.fromLTRB(30, 0, 30, 0),
                      child: Text(
                        //'Tu cos tam skonfigurujesz.',
                        'Zacznij od szybkiej konfiguracji lub zeskanuj QR kod aby dodać urządzenie',
                        textAlign: TextAlign.center,
                        style: GoogleFonts.varelaRound(
                          fontSize: 16,
                          color: Colors.white70,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const BottomActionButtons(
              leftButton: BottomActionButton(
                icon: Icon(Icons.camera_alt),
                label: Text(
                  'Zeskanuj kod',
                  style: TextStyle(
                    fontFamily: 'Varela',
                  ),
                ),
                primaryColor: Colors.white,
                onPrimaryColor: Color(0xFF1565C0),
              ),
              rightButton: BottomActionButton(
                label: Text(
                  'Zacznij',
                  style: TextStyle(
                    fontFamily: 'Varela',
                  ),
                ),
                primaryColor: Colors.white,
                onPrimaryColor: Color(0xFF1565C0),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
