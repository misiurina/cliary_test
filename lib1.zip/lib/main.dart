import 'package:cliary_test/TestScreens/set_up_services_screen.dart';
import 'package:cliary_test/TestScreens/welcome_screen.dart';
import 'package:cliary_test/components/add_service_group_list_item.dart';
import 'package:cliary_test/components/add_service_list_item.dart';
import 'package:cliary_test/components/service_group_list.dart';
import 'package:cliary_test/components/service_group_list_item.dart';
import 'package:cliary_test/components/services_list.dart';
import 'package:flutter/material.dart';

import 'package:cliary_test/contact_picker/pick_contact_list.dart';
import 'package:flutter/services.dart';

import 'components/service_list_item.dart';

void main() {
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Color(0xFF1565C0),
    statusBarIconBrightness: Brightness.light,
  ));

  runApp(const Cliary());
}

class Cliary extends StatelessWidget {
  const Cliary({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // return const WelcomeScreen();
    return MaterialApp(
      title: 'cliary',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        brightness: Brightness.light,
        appBarTheme: Theme.of(context).appBarTheme.copyWith(brightness: Brightness.light),
      ),
      home: const SetUpServicesScreen(),
        // body: Center(child: AddServiceListItem()),
        // body: Center(child: AddServiceGroupListItem()),
        /*body: Center(
          child: ServiceGroupListItem(
            groupName: 'Depilacje',
            color: 0xFFB5EAD6,
          ),
        )*/
        // body: Center(
        //   child: ServiceListItem(
        //     displayName: 'Depilacja pastą cukrową',
        //     description: 'Jak zwykła, tylko pastą cukrową',
        //     time: '~30 min',
        //     price: '100 zł',
        //   ),
        // ),
        // body: WelcomeScreen(),
    );
  }
}

class ActivePage extends StatefulWidget {
  const ActivePage({Key? key}) : super(key: key);

  @override
  State<ActivePage> createState() => _ActivePageState();
}

class _ActivePageState extends State<ActivePage> {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Wybierz klientów'),
      ),
      body: const ContactPickerList(),
    );
  }
}
